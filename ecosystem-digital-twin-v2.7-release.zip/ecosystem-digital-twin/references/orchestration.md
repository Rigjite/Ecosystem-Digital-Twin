# Orchestration, multi-agent work, and red team

## Contents
Scale tiers · Roles · Task contracts · Conflict resolution · Independence
rules · Red-team gates (A design, B calibration, C delivery) · Cost and
effort discipline · Implementation note · Multi-model runner protocol

A digital twin built by one operator follows Phases 0–6 directly. Larger or
higher-stakes builds run through an orchestrated multi-agent layer defined
here. The layer exists to buy **independence and parallelism** — separate
eyes on calibration, adversarial review of claims — not ceremony. If a build
is small, the layer collapses to one operator plus one red-team pass; it is
never allowed to cost more than the errors it prevents.

## Scale tiers

| Tier | When | Who works | Red team |
|---|---|---|---|
| **S — Single operator** | One domain, monitoring or descriptive build, low-stakes decisions | The operator runs all phases | One independent pass at Gate C (before delivery) |
| **M — Orchestrated specialists** | Multi-domain or multi-source build, predictive claims, client-facing deliverable | Orchestrator + data scout + evidence scout + domain modeler in parallel workstreams; calibration auditor independent of the modeler | Gates B and C |
| **L — Full council** | Regulatory, public-health, large-money, or publicly contested decisions | Tier M plus a heterogeneous council (distinct expert personas per member) for design and scenario decisions | Gates A, B, and C |

The tier is chosen in Phase 0 and recorded in the passport, with its reason.
Escalating a tier mid-build is allowed; silently working above the recorded
tier's discipline is not.

## Roles

Personas are seniority-framed and **distinct per agent** — a shared persona
across agents produces duplicated reasoning and is a defect. Frame each as:
role + seniority + scale + working style (+ a comparative clause for
forecast or strategy work: find analogues in other countries or basins,
extract the pattern, state the conditions under which it transfers).

1. **Orchestrator** — senior environmental systems integrator. Owns the
   passport, the phase gates, task contracts, conflict resolution, and the
   single client-facing voice. Never delegates the two human decisions:
   Phase 0 framing (what decision the twin serves) and the Phase 5
   recommendation sign-off — those stay with the owner.
2. **Data scout** — senior environmental data engineer. Builds the source
   matrix and fall-back hierarchy (Phase 1), runs the data quality gate.
3. **Evidence scout** — senior systematic-review methodologist. Builds the
   evidence inventory via `references/evidence-sources.md`, screens by the
   evidence hierarchy, flags abstract-only claims.
4. **Domain modeler** — senior scientist of the object's domain (limnologist,
   hydrologist, agronomist, air-quality modeler, conservation biologist).
   Builds the state model and indicator selection (Phase 2), drafts
   calibration (Phase 3) and scenarios (Phase 5).
5. **Calibration auditor** — senior environmental statistician, **never the
   modeler**. Designs the hindcast split before fitting, verifies metrics
   against the naive baseline, enforces declared failure thresholds.
6. **Red team** — adversarial reviewer (below). Independent of every role
   whose output it attacks.
7. **Optional specialists** — geospatial/remote-sensing analyst; ELSA and
   stakeholder reviewer for sensitive sites. Added by name in the passport
   when the object needs them, not by default.

## Task contracts

Every agent works from a written contract issued by the orchestrator:

- the slice of the object passport the task serves (boundaries, decision,
  maturity target);
- the inputs provided, by manifest ID — an agent never receives "the whole
  project" by default;
- the required output: artifact type, structure, provenance fields, and the
  explicit instruction to **return gaps, not guesses** — an agent that
  cannot support a value reports it as unmeasured;
- the prohibition list: no client contact, no external publication, no
  precise sensitive-species locations in any output, no threshold without a
  named anchor;
- the acceptance check the orchestrator will run before the output enters
  the build.

Outputs enter the build only through the orchestrator, carrying manifest
IDs. Agent prose without provenance is working notes, not build material.

## Conflict resolution

Agents will disagree. Resolution follows the evidence hierarchy, not votes:

1. direct observations of the object;
2. law, standards, and guidelines of the object's jurisdiction;
3. peer-reviewed evidence, weighted by the hierarchy in
   `references/evidence-sources.md`;
4. model output, weighted by its verification scores;
5. agent judgment.

The orchestrator records each material disagreement, the tier that decided
it, and the rationale, in the provenance log. A disagreement that no tier
can settle becomes a stated uncertainty in the deliverable — never a silent
majority decision about a fact.

## Independence rules

- The calibration auditor is not the modeler; the red team is not the
  builder of anything it attacks; where models differ per role, the
  red-team model differs from the arbiter/orchestrator model.
- Personas are distinct per agent (see Roles). One shared persona across a
  council voids the run's value: redo with distinct lenses or downgrade
  the tier honestly.
- The red team sees the artifact and its provenance, not the builder's
  intentions or excuses. Context that would soften the attack is withheld
  until the attack is recorded.

## Red-team gates

The red team's job is to attack the twin the way a hostile reviewer, a
regulator, or reality would. Each attack is recorded with severity
(critical / material / minor), the evidence demanded, and its disposition:
**fixed**, **claim narrowed**, or **risk accepted with owner sign-off**.
An unresolved critical attack blocks the gate.

**Gate A — design (after Phase 2; Tier L, optional in M).** Attacks:
indicators without sources or methods ("indicator theater"); thresholds
imported without a jurisdiction check ("threshold smuggling"); satellite
proxies presented as measurements; missing upstream catchment or airshed
boundaries; state variables that no data stream can feed; maturity target
above what the data inventory can support; sensitive-species leakage paths
in planned outputs.

**Gate B — calibration (after Phase 3; Tiers M and L).** Attacks: tuning on
the scoring data; naive baseline missing or cherry-picked; metric shopping
(reporting only the flattering metric); an assimilation method named
without the data density it requires ("assimilation theater"); failure
periods omitted; uncertainty absent from forecast outputs; a failed
calibration silently re-scoped instead of narrowing the twin's claims.

**Gate C — delivery (before Phase 6; all tiers).** Attacks: scenario
cherry-picking; scoring weights moved after results were seen; nature-based
options skipped without the passport record; an engineered recommendation
without its burden-of-justification statement; headline numbers without
manifest IDs; claims above the declared maturity level; decision-value
claims for a twin that has not yet informed a decision; client conflict of
interest not disclosed; precise sensitive locations anywhere in the package.

A build that passes all gates has earned its claims. A build that cannot
pass ships narrower claims — the red team's product is honesty, not delay.

## Cost and effort discipline

- Agents are convened per phase or per gate, not kept running. Every
  multi-model run is a recorded cost in the project log.
- Tier S is the default. Multi-agent overhead is justified by stakes,
  domains in play, or predictive claims — never by the availability of the
  tooling.
- A red-team pass is the last element cut from a budget and the first
  restored: a small build can skip specialists, but shipping unreviewed
  claims is how twins become score theater.

## Implementation note

The council mechanics in this reference can be implemented with any
multi-model runner that supports: an explicitly chosen model set (never
silent defaults), a distinct persona per council member, and a red-team
pass executed by a model different from the arbiter's. The operator's own
standing rules for which runs are worth their cost govern whether a run
happens; this reference governs what the roles owe each other once it does.

## Multi-model runner protocol

How the layer runs when the council members are models reached through an
API — for example a personal agent with its own code sandbox that calls
other developers' models through a model router — and only one participant
can execute code.

**Compute and judgment are split.**

- **One execution host.** Exactly one participant runs code: the
  orchestrator's environment (a coding agent, a CI runner, or an agent's
  cloud sandbox). It installs the skill at a pinned version (tag or commit,
  recorded in the passport) and runs every script. The scripts need only the
  Python standard library, so any sandbox with Python 3.9+ will do.
- **Text-only council.** Council members and the red team receive briefs and
  return text. They never compute, re-derive, or estimate a number: a
  number a member states that is not in a script output or the manifest is
  discarded, and the member is asked again.
- **The brief.** One brief per question, holding: the passport slice; the
  script's printed JSON summary (lists capped by `--max-items`, totals kept)
  and the manifest IDs behind it; the rule or gate being tested; and the
  answer form required — attack or finding, severity, the evidence that
  would settle it. Raw series stay with the execution host.

**What may leave the client boundary.** Agent platforms may be able to
reach their own sandboxes, and a model router may forward a brief to
several providers. Before any client data enters a multi-model run, the
passport records the data flow (execution host, router, each provider and
what it receives) and the client's written consent to it. Briefs carry
summaries, never raw client series, never personal data; occurrence data
are generalized with `scripts/generalize_coords.py` and pass `--check`
before they appear in any brief.

**Council composition.** Three to five members from at least two model
developers, each named by exact model ID and the date of the run — a model
family name is not enough to reproduce a run. The red-team model differs
from the arbiter's (Independence rules). Distinct personas per member, as in
Roles.

**Where the council works — and where it never does.** Phase 0 design,
Gates A–C, and the Phase 5 recommendation. It is never in the Phase 4 alert
path: alerts come from `scripts/alert_bands.py` and go to a named human. A
model may explain an alert afterwards; it never triggers, delays, or
suppresses one. A call to several models takes minutes; a hypoxia window
does not wait.

**Record and cost.** Every council exchange is logged — model ID, date,
the brief's SHA-256 hash, the response, and the orchestrator's disposition
— and the log enters the provenance package as a dataset in the build index
(`scripts/build_manifest.py`). Each run has a cost cap set before it starts,
and the spend is recorded next to the log. Disagreements are settled by the
evidence hierarchy above, never by counting votes.

