# Uncertainty, information value, forecast registry, and the counterfactual twin

## Contents
1. Quantitative uncertainty
2. Value of information and adaptive sampling
3. Forecast registry and pre-registration (`scripts/registry.py`)
4. The counterfactual twin — proving improvement
5. Historical-event replay — the twin as a trainer

Four methods that turn the twin's honesty from wording into arithmetic and
institutions. They are used at decision and predictive maturity levels;
simpler builds state why they are not yet applied.

## 1. Quantitative uncertainty

Every headline output carries a **computed** uncertainty, not an adjective.

**Sources, always separated in the report:** measurement error; input and
forcing error (weather, loads, boundary conditions); parameter uncertainty;
structural (model-choice) uncertainty; scenario uncertainty (the future
itself). A single blended "±" that hides which source dominates is a defect.

**Method ladder** (climb as stakes and compute allow):

1. **Error propagation / Monte Carlo ensembles** — vary inputs and
   parameters within their documented distributions; report prediction
   intervals and exceedance probabilities, not just means.
2. **Bayesian calibration** where data support it — priors documented from
   the evidence layer (`references/evidence-sources.md`), posterior ranges
   reported; a prior without a named source is an opinion, labeled as such.
3. **Global sensitivity analysis** — screening (Morris) then variance-based
   indices (Sobol or equivalent) on the headline outputs: which inputs and
   parameters actually drive the result. This ranking is the input to
   value-of-information analysis (section 2).
4. **Structural comparison** — at least two model structures or a hybrid
   pair for decision-level claims; where structures disagree, the
   disagreement is reported as part of the uncertainty.

**Uncertainty budget.** Each headline output ships with a small budget
table: source → contribution to total variance (or a ranked qualitative
share where computation is not yet possible, labeled as such).
`scripts/uncertainty_budget.py` builds it from ensemble runs — one
one-at-a-time ensemble per source plus a joint ensemble — reports each
source's share, the reducible share, the interaction term (large → move to
Sobol indices), and a percentile interval from the joint ensemble only. The budget
tells the client what would have to improve for the answer to sharpen —
and what cannot improve because the uncertainty is in the future itself.

Rule: a number whose uncertainty cannot be computed yet is published with
the reason and the plan to compute it — never with a decorative interval
invented for appearance.

**Explainability under pressure.** When a decision must be made under time
pressure, the twin states in plain terms what the model used, what it did
not use, and how confident it is — the drivers of the result in one or two
sentences, recorded on the scenario card. A verdict without that
explanation is not a decision input; it is a black box, and the
decision-maker is told so.

## 2. Value of information and adaptive sampling

Monitoring budgets are finite; the twin spends them where they matter.

- **Uncertainty map.** Maintain a map/register of where and when decision-
  relevant uncertainty is highest (places, seasons, variables) — from the
  sensitivity ranking and the uncertainty budgets.
- **Next-measurement recommendation.** At every verification cycle, rank
  candidate measurements (new sensor, extra sampling dates, one-off survey)
  by expected reduction in decision uncertainty per unit cost. State the
  decision each candidate serves; a measurement that serves no decision is
  not recommended, however interesting scientifically.
- **Spread-informed sampling priority.** The concrete rule that turns
  "information has value" into "sample here next": rank the next sampling
  targets (stations, dates, variables) by disagreement between the
  admitted model and the naive benchmark, or between candidate models
  (`scripts/uncertainty_budget.py sampling-priority` — input: target +
  model/naive or model_a/model_b; disagreement = |a − b|; ties by input
  order). Sample the top target next: where the models disagree most, a
  measurement decides between them. A target whose models agree needs no
  sample — the twin already knows. The ranking is recorded on the
  scenario card (`assets/templates.md` §6) so the next field campaign is
  a decision of the twin, not a guess. (Source: lake platforms — Sensors
  2026, 26, 6175, spread-informed mobile sampling.)
- **Sensor placement** follows the same logic: gradient coverage (inflow →
  center → outflow; upwind → source → downwind), event capture (the place
  where the event shows first), redundancy for the fall-back hierarchy,
  and access/maintenance reality.
- **Adaptive intensification.** When a forecast's uncertainty crosses the
  threshold where a pending decision flips, sampling intensifies for that
  window (event-based sampling), then returns to baseline cadence.
- **Stopping rule.** When the expected value of the next measurement falls
  below its cost, say so and stop expanding the network. The twin that
  always wants more sensors is a budget risk, not a quality signal.
- **Realized value is checked.** Each recommendation records the expected
  uncertainty reduction; the next cycle compares what was realized. A
  value-of-information practice that never audits itself becomes guesswork.

## 3. Forecast registry and pre-registration

Predictive claims are earned in public, in advance.

- **Every forecast is registered before its outcome is knowable:** forecast
  ID; issue timestamp; quantity or event; horizon; value or probability
  with its interval and the method that computed it; model and version;
  input data by manifest ID; the verification metric declared for it. The
  registry is **append-only** — entries are never edited after issue;
  corrections are new entries that reference the old, and the old entry
  stays in the score. `scripts/registry.py` implements this: it stamps the
  registration clock (no back-dating), refuses a forecast whose outcome is
  already knowable, refuses an interval without its method, chains every
  record to the previous one by SHA-256 so `verify` exposes any later edit,
  and lists overdue forecasts that were never resolved. The chain proves
  nothing was changed afterwards; anchor its latest hash outside the build
  (a commit, an email to the owner) to prove when it was written.
- **Verification is computed against the registry**, exactly as issued —
  never reconstructed from memory or from a later model version. This is
  what makes the standing verification scores in Phase 4 evidence rather
  than narrative.
- **Metadata follows the ecological-forecasting community convention**
  (Dietze et al. 2023, Ecosphere 14: e4686 — the EFI output and metadata
  standard): forecast, model, and uncertainty described in a standard,
  machine-readable form so scores are comparable across builds and over time.
- A forecast found to have been issued but not registered is treated as
  not issued: it earns no verification credit and supports no claim.
- **Alerts are trialled separately from the model.** A model can beat its
  benchmark and still cry wolf, or stay silent when it matters — so the
  alerts themselves are scored on a hold-out window
  (`scripts/skill_scores.py alert-trial`): precision (relevant alerts /
  all alerts), miss rate (missed critical events / all critical events),
  alarm volume. The trial passes only at precision >= 0.9, zero missed
  criticals, and the alarm count within cap; a window with no alerts is a
  FAIL, because a silent trial proves nothing. The trial is a separate
  gate from model admission (SS_RMSE > 0): both must pass. (Source:
  Southern Water / Wessex Water's 3-month Bath trial: 92% of alerts
  relevant, 8% false positives, zero missed pollution incidents, 97%
  alarm reduction, 4,500 → 138.)

- **Mismatch register — learning from the pattern of the error.** A
  failed validation is a score; the mismatch register is the lesson. For
  spatial or categorical predictions, record where observed ≠ modeled
  (`scripts/mismatch.py` — two tables, observed vs modeled, cell by
  cell): the *extent* (fraction of observed flooded cells correctly
  predicted) alongside the level score, the misses (observed but not
  modeled) and the false alarms (modeled but not observed), the inferred
  hidden cause as a [ГИПОТЕЗА]/[НЕТ ДАННЫХ] item, and the measurement
  that would confirm it. The register entry is recorded in the
  calibration audit (`assets/templates.md` §12). The register is the
  learning log, not a gate: the alert trial and the hindcast
  reproduction gate are pass/fail — a failed gate revokes admission —
  while the register explains *why* a validation was bad and turns the
  failure into the next data requirement. (The alert trial adds a third
  verdict, INCONCLUSIVE_QUIET_WINDOW, for a window with no alerts and no
  critical events: nothing to score, so it neither admits nor rejects.) A failed validation with no
  register entry is a score with no lesson. (Source: Patos Lagoon —
  where the flood model missed flooding, the team inferred a hidden
  pathway, an underground drainage network without backflow control,
  from the pattern of the disagreement itself.)

## 4. The counterfactual twin — proving improvement

When the owner implements a measure, the twin splits:

- **Freeze the no-action baseline.** At the implementation decision, the
  baseline twin's configuration, parameters, and management inputs are
  frozen and archived with manifest IDs. This frozen twin is the
  counterfactual: what the model says would have happened without the
  measure.
- **Run both twins on the same observed forcings.** Weather, inflows, and
  other external drivers are identical; only the management inputs differ.
  The difference between the action twin and the counterfactual — reported
  with its uncertainty (section 1) — is the twin's estimate of the
  measure's effect and of damage avoided.
- **No silent re-anchoring.** If the model is later improved, both twins
  are re-run and the change in the estimated effect is logged and
  disclosed. Retroactively improving a claimed effect by quietly updating
  only the baseline is fabrication, and the red team treats it as such
  (Gate C).
- **Field evidence outranks the counterfactual.** Where BACI-type field
  data (before–after/control–impact) or direct measurements of the effect
  exist, they decide; the counterfactual is the estimate used where and
  until such data arrive, labeled as model-based.
- **Avoided-damage reporting.** Each review cycle reports: observed state,
  counterfactual state, estimated effect with interval, and the option
  card's predicted effect (Phase 5) next to both — so the owner sees what
  was promised, what the model attributes, and what was measured, as three
  distinct numbers.

This mode is what turns a twin from a monitoring expense into proof of
impact — for the owner's own decisions first, and for funders and
regulators when they ask what the money bought.

Scenario 0 is class 0 of the scenario taxonomy
(`references/scenarios.md`): planning and what-if scenarios are judged
against it, never instead of it.

## 5. Historical-event replay — the twin as a trainer

A twin that proves it would have warned about a real past event is one a
client can trust. The replay protocol is that proof, run on the event as
it happened:

- **Pick a named historical extreme from the object's own record** — a
  flood peak, a bloom, a fire season, a fish kill — with a dated event
  and a dated data series leading up to it.
- **Cut the data at the last observation before the event.** The
  pipeline (QC → trend → alert bands, the existing scripts) sees only
  data up to the cutoff — never the event itself. A replay that peeks
  at the event is not a replay; it is a post-hoc fit, and the red team
  treats it as such.
- **Run the pipeline and record WHETHER AND WHEN the alert fired** —
  the alert's start timestamp and the lead time in days from the alert
  to the event. A lead time measured this way fills the lead-time
  register (v2.4) with a measured value, not a claimed one.
- **A miss is a finding, not a failure to report.** If the alert did
  not fire, the replay records `alert_fired: no` and no lead time — and
  the reason is investigated (band too high, window too long, driver
  unmeasured) and recorded as a [ГИПОТЕЗА]/[НЕТ ДАННЫХ] item with the
  measurement that would confirm it.
- **Record the replay in the registry** (`scripts/registry.py replay`):
  id, event (named), event date, data cutoff, alert fired (yes/no),
  lead time in days (when the alert fired), method (the pipeline run),
  inputs (manifest ids of the data up to the cutoff), model and version.
  The record is hash-chained like every registry record, so a replay
  recorded as run cannot be edited afterwards; `score` ignores replay
  records (only forecasts are scored).

**Boundary — replay vs storyline.** A replay runs the pipeline on the
event AS IT HAPPENED (a verification: would the twin have warned in
time?); a storyline (`references/scenarios.md` — the Storyline class)
replays an event under CHANGED drivers (a scenario: what if it happened
again, hotter or drier?). The two are recorded separately and never
substitute for each other: a storyline never claims the alert fired, and
a replay never claims a changed-driver outcome. (Source: Digital Baikal —
the managed-mudflow twin as a trainer, replaying the 2019 mudflow that
passed critically close to nine BPPM sludge ponds.)

**Boundary — replay vs hindcast gate.** A replay checks whether the twin
would have WARNED in time about a historical extreme (the alert
pipeline on the event as it happened); the hindcast reproduction gate
(`references/scenarios.md` — Phase 5 rule) checks whether the scenario
MODEL reproduces the observed historical period with the intervention
switched off, before its delta is trusted. The replay verifies an alert;
the gate validates a scenario model. A successful replay never validates
a scenario delta, and a passed gate never claims the alert fired.
